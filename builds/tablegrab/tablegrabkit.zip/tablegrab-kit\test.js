// Runs the real minified bookmarklet in headless Chromium against the four
// deliberately hostile tables on the demo page and asserts exact CSV output.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const code = fs.readFileSync('tablegrab.min.js', 'utf8');
const url = 'file://' + path.resolve('tablegrab.html');

let failures = 0;
function check(name, actual, expected) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) {
    console.log('  PASS  ' + name);
  } else {
    failures++;
    console.log('  FAIL  ' + name);
    console.log('        expected: ' + e);
    console.log('        actual  : ' + a);
  }
}
function checkContains(name, haystack, needle) {
  if (String(haystack).indexOf(needle) !== -1) {
    console.log('  PASS  ' + name);
  } else {
    failures++;
    console.log('  FAIL  ' + name + '  (missing: ' + needle + ')');
    console.log('        in: ' + String(haystack).slice(0, 400));
  }
}

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const consoleErrors = [];
  page.on('pageerror', (e) => consoleErrors.push(String(e)));
  await page.goto(url);

  // Fire the bookmarklet exactly as a browser would.
  await page.evaluate(code);

  const api = await page.evaluate(() => {
    const g = window.__tableGrab__;
    return {
      count: g.found.length,
      labels: g.found.map((f) => f.kind)
    };
  });

  console.log('\nDetection');
  check('finds 4 tables/grids and ignores layout markup', api.count, 4);
  check('three real tables plus one ARIA grid', api.labels, ['table', 'table', 'table', 'grid']);

  const grab = (i) => page.evaluate((i) => {
    const g = window.__tableGrab__;
    const rows = g.extract(g.found[i]);
    return { rows: rows, csv: g.csv(rows) };
  }, i);

  /* ---------------------------------------------------------- table 1 */
  console.log('\nTable 1: merged cells, hidden column, accounting negatives');
  const t1 = await grab(0);
  check('the two header rows collapse into one, joining group with sub-label',
    t1.rows[0], ['Region', 'Segment', 'Revenue Q1', 'Revenue Q2', 'Net change']);
  check('a rowspan label is not repeated inside the merged header',
    t1.rows[0][0], 'Region');
  check('footnote marker stripped from the Revenue header',
    t1.rows[0][2], 'Revenue Q1');
  check('exactly one header row survives the merge',
    t1.rows[1][0], 'North America');
  check('rowspan region label filled down into every sub-row',
    [t1.rows[1][0], t1.rows[2][0], t1.rows[3][0]],
    ['North America', 'North America', 'North America']);
  check('currency and thousands separators removed',
    t1.rows[1][2], '1284900');
  check('accounting parentheses become a real negative',
    t1.rows[2][4], '-42180');
  check('European format 1.284.900,50 converted',
    t1.rows[4][2], '1284900.50');
  check('European negative in parentheses converted',
    t1.rows[5][4], '-13177.75');
  check('footnote marker stripped from Public sector label',
    t1.rows[3][1], 'Public sector');
  check('hidden template row dropped', t1.rows.length, 6);
  checkContains('no hidden internal-margin values anywhere in the CSV',
    t1.csv.indexOf('38.4') === -1 ? 'clean' : t1.csv, 'clean');

  /* ---------------------------------------------------------- table 2 */
  console.log('\nTable 2: line breaks, nbsp, links, exponents');
  const t2 = await grab(1);
  check('multi-line address collapses to one cell, no extra rows',
    t2.rows[1][1], '4120 Harbour Way Suite 300 Baltimore, MD 21230');
  check('address cell is quoted because it contains a comma',
    t2.csv.split('\r\n')[1].indexOf('"4120 Harbour Way Suite 300 Baltimore, MD 21230"') !== -1, true);
  check('trailing footnote asterisk stripped from vendor name',
    t2.rows[1][0], 'Brightline Facilities');
  check('superscript with text after it is kept as an exponent',
    t2.rows[1][2], '1,850 m2 per visit');
  check('row count is 4 (header plus three vendors)', t2.rows.length, 4);
  check('currency stripped from rate', t2.rows[3][3], '4120.00');

  /* ---------------------------------------------------------- table 3 */
  console.log('\nTable 3: ARIA div grid');
  const t3 = await grab(3);
  check('ARIA grid read as a table with the hidden column dropped',
    t3.rows[0], ['Ticket', 'Account', 'Priority', 'Age (days)']);
  check('grid rows extracted', t3.rows.length, 4);
  check('no rep names leak from the hidden column',
    t3.csv.indexOf('Castellanos'), -1);

  /* ---------------------------------------------------------- table 4 */
  console.log('\nTable 4: formula injection');
  const t4 = await grab(2);
  const t4lines = t4.csv.split('\r\n');
  check('leading = neutralised with an apostrophe in the CSV',
    t4lines[1].indexOf(',"\'=HYPERLINK') > 0, true);
  check('leading + neutralised', t4lines[2].indexOf(',\'+1+cmd') > 0, true);
  check('leading @ neutralised', t4lines[3].indexOf(',\'@SUM') > 0, true);
  check('genuine negative number NOT prefixed', t4.rows[1][2], '-1250.00');
  check('genuine negative number NOT prefixed (2)', t4.rows[3][2], '-84.20');
  checkContains('payload lands quoted as text in the CSV', t4.csv, '"\'=HYPERLINK(');

  /* ------------------------------------------- hidden column / row toggles */
  console.log('\nOption: hidden columns and hidden rows are independent');
  const cols = await page.evaluate(() => {
    const g = window.__tableGrab__;
    g.opts.includeHiddenCols = true;
    const rows = g.extract(g.found[0]);
    g.opts.includeHiddenCols = false;
    return rows;
  });
  check('hidden column reappears on its own', cols[0].length, 6);
  check('the hidden template row does NOT come with it', cols.length, 6);

  const rowsOnly = await page.evaluate(() => {
    const g = window.__tableGrab__;
    g.opts.includeHiddenRows = true;
    const rows = g.extract(g.found[0]);
    g.opts.includeHiddenRows = false;
    return rows;
  });
  check('hidden row reappears on its own', rowsOnly.length, 7);
  check('no hidden column comes with it', rowsOnly[0].length, 5);

  const bothHidden = await page.evaluate(() => {
    const g = window.__tableGrab__;
    g.opts.includeHiddenCols = true; g.opts.includeHiddenRows = true;
    const rows = g.extract(g.found[0]);
    g.opts.includeHiddenCols = false; g.opts.includeHiddenRows = false;
    return rows;
  });
  check('both options together restore the full grid', bothHidden.length, 7);
  check('both options together restore every column', bothHidden[0].length, 6);

  const unmerged = await page.evaluate(() => {
    const g = window.__tableGrab__;
    g.opts.mergeHeaders = false;
    const rows = g.extract(g.found[0]);
    g.opts.mergeHeaders = true;
    return rows;
  });
  check('turning header merging off restores the raw two-row header',
    unmerged[0], ['Region', 'Segment', 'Revenue', 'Revenue', 'Net change']);
  check('and the second raw header row is intact',
    unmerged[1], ['Region', 'Segment', 'Q1', 'Q2', 'Net change']);


  /* --------------------------------------------------- numbers-off toggle */
  const rawNumbers = await page.evaluate(() => {
    const g = window.__tableGrab__;
    g.opts.cleanNumbers = false;
    const rows = g.extract(g.found[0]);
    g.opts.cleanNumbers = true;
    return rows;
  });
  console.log('\nOption: clean numbers off');
  check('raw text preserved when cleaning is off', rawNumbers[1][2], '$1,284,900');

  /* ------------------------------------------------------------ UI checks */
  console.log('\nUI');
  const ui = await page.evaluate(() => {
    const host = document.querySelector('[data-tablegrab]');
    const root = host && host.shadowRoot;
    return {
      hasShadow: !!root,
      badges: root ? root.querySelectorAll('.tg-badge').length : 0,
      outlines: root ? root.querySelectorAll('.tg-out').length : 0,
      bar: root ? !!root.querySelector('.tg-bar') : false
    };
  });
  check('UI is isolated in a shadow root', ui.hasShadow, true);
  check('one badge per table', ui.badges, 4);
  check('one outline per table', ui.outlines, 4);
  check('toolbar rendered', ui.bar, true);

  await page.screenshot({ path: 'proof-overlay.png', fullPage: false });
  await page.evaluate(() => window.scrollTo(0, document.querySelector('#try').offsetTop - 40));
  await page.waitForTimeout(200);
  await page.screenshot({ path: 'proof-tables.png' });

  // Esc teardown, then re-run to prove the toggle works.
  await page.keyboard.press('Escape');
  const goneAfterEsc = await page.evaluate(() => !document.querySelector('[data-tablegrab]'));
  check('Escape removes every trace of the overlay', goneAfterEsc, true);
  await page.evaluate(code);
  await page.evaluate(code);
  const goneAfterToggle = await page.evaluate(() => !document.querySelector('[data-tablegrab]'));
  check('clicking the bookmark twice toggles it off', goneAfterToggle, true);

  /* ------------------------------------------- real download round trip */
  await page.evaluate(code);
  const dl = page.waitForEvent('download');
  await page.evaluate(() => {
    const root = document.querySelector('[data-tablegrab]').shadowRoot;
    root.querySelectorAll('.tg-badge')[0].querySelector('button').click();
  });
  const download = await dl;
  const file = await download.path();
  const csv = fs.readFileSync(file, 'utf8');
  console.log('\nDownload');
  check('file name derived from page title and caption',
    /q2-regional-performance\.csv$/.test(download.suggestedFilename()), true);
  check('UTF-8 BOM present for Excel', csv.charCodeAt(0), 0xfeff);
  check('CRLF line endings', csv.indexOf('\r\n') > 0, true);
  checkContains('downloaded CSV contains the filled-down region label',
    csv, 'North America,Mid-market,612455,570275,-42180');

  console.log('\n--- downloaded CSV ---');
  console.log(csv.replace(/^﻿/, ''));
  console.log('----------------------');

  check('no uncaught page errors', consoleErrors, []);

  await browser.close();
  console.log(failures === 0 ? '\nALL CHECKS PASSED' : '\n' + failures + ' CHECK(S) FAILED');
  process.exit(failures === 0 ? 0 : 1);
})();
