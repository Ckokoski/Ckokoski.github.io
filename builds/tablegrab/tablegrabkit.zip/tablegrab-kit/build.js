// Conservative, tokenizer-based comment stripper + indentation collapser.
// No identifier mangling: correctness over bytes. Output is verified by
// running it in headless Chromium against the test suite before shipping.
const fs = require('fs');

function strip(src) {
  let out = '';
  let i = 0;
  const n = src.length;
  // Tracks whether a '/' starts a regex literal or is a division operator.
  let prevSignificant = '';

  const regexAllowedAfter = /[=(,:;!&|?{}[\]+\-*%~^<>]$/;
  const keywordRegex = /(^|[^\w$.])(return|typeof|instanceof|in|of|new|delete|void|throw|case|do|else|yield|await)$/;

  while (i < n) {
    const c = src[i];
    const c2 = src[i + 1];

    if (c === '/' && c2 === '/') {
      while (i < n && src[i] !== '\n') i++;
      continue;
    }
    if (c === '/' && c2 === '*') {
      i += 2;
      while (i < n && !(src[i] === '*' && src[i + 1] === '/')) i++;
      i += 2;
      continue;
    }
    if (c === '"' || c === "'" || c === '`') {
      const quote = c;
      let s = c;
      i++;
      while (i < n) {
        if (src[i] === '\\') { s += src[i] + src[i + 1]; i += 2; continue; }
        s += src[i];
        if (src[i] === quote) { i++; break; }
        i++;
      }
      out += s;
      prevSignificant = quote;
      continue;
    }
    if (c === '/') {
      const trimmed = out.replace(/\s+$/, '');
      const isRegex = trimmed === '' || regexAllowedAfter.test(trimmed) || keywordRegex.test(trimmed);
      if (isRegex) {
        let s = '/';
        i++;
        let inClass = false;
        while (i < n) {
          if (src[i] === '\\') { s += src[i] + src[i + 1]; i += 2; continue; }
          if (src[i] === '[') inClass = true;
          else if (src[i] === ']') inClass = false;
          else if (src[i] === '/' && !inClass) { s += '/'; i++; break; }
          s += src[i];
          i++;
        }
        while (i < n && /[a-z]/.test(src[i])) { s += src[i]; i++; }
        out += s;
        prevSignificant = '/';
        continue;
      }
    }
    out += c;
    if (!/\s/.test(c)) prevSignificant = c;
    i++;
  }
  return out;
}

// Second pass: collapse whitespace outside of strings and regex literals.
// A space is only kept when dropping it would glue two word characters
// together, or would turn "+ +" / "- -" into "++" / "--".
function squeeze(src) {
  const word = /[A-Za-z0-9_$\\]/;
  let out = '';
  let i = 0;
  const n = src.length;

  const regexAllowedAfter = /[=(,:;!&|?{}[\]+\-*%~^<>]$/;
  const keywordRegex = /(^|[^\w$.])(return|typeof|instanceof|in|of|new|delete|void|throw|case|do|else|yield|await)$/;

  while (i < n) {
    const c = src[i];
    if (c === '"' || c === "'" || c === '`') {
      const quote = c;
      out += c;
      i++;
      while (i < n) {
        if (src[i] === '\\') { out += src[i] + src[i + 1]; i += 2; continue; }
        out += src[i];
        if (src[i] === quote) { i++; break; }
        i++;
      }
      continue;
    }
    if (c === '/') {
      const trimmed = out.replace(/\s+$/, '');
      if (trimmed === '' || regexAllowedAfter.test(trimmed) || keywordRegex.test(trimmed)) {
        out += '/';
        i++;
        let inClass = false;
        while (i < n) {
          if (src[i] === '\\') { out += src[i] + src[i + 1]; i += 2; continue; }
          if (src[i] === '[') inClass = true;
          else if (src[i] === ']') inClass = false;
          else if (src[i] === '/' && !inClass) { out += '/'; i++; break; }
          out += src[i];
          i++;
        }
        while (i < n && /[a-z]/.test(src[i])) { out += src[i]; i++; }
        continue;
      }
      out += c;
      i++;
      continue;
    }
    if (/\s/.test(c)) {
      let j = i;
      while (j < n && /\s/.test(src[j])) j++;
      const left = out[out.length - 1] || '';
      const right = src[j] || '';
      const mustKeep =
        (word.test(left) && word.test(right)) ||
        ((left === '+' || left === '-') && left === right);
      if (mustKeep) out += ' ';
      i = j;
      continue;
    }
    out += c;
    i++;
  }
  return out;
}

// encodeURIComponent escapes { } ( ) , ; : / = etc, which are everywhere in
// JS. Only the characters that would actually break an href need escaping.
function toHref(code) {
  return 'javascript:' + code.replace(/[%"#<>&\s]/g, (ch) => {
    if (ch === ' ') return '%20';
    return '%' + ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0');
  });
}

const src = fs.readFileSync('tablegrab.src.js', 'utf8');
const min = squeeze(strip(src));
fs.writeFileSync('tablegrab.min.js', min);

const bookmarklet = toHref(min);
fs.writeFileSync('tablegrab.bookmarklet.txt', bookmarklet);

// The href is already free of " < > &, so it is safe in an HTML attribute.
if (/["<>&]/.test(bookmarklet)) throw new Error('bookmarklet is not attribute-safe');

const escapeHtml = (s) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

const page = fs
  .readFileSync('tablegrab.template.html', 'utf8')
  .split('{{BOOKMARKLET}}').join(bookmarklet)
  .split('{{SRCLINES}}').join(String(src.split('\n').length))
  .split('{{SOURCE}}').join(escapeHtml(src));
fs.writeFileSync('tablegrab.html', page);

console.log('source     :', src.length, 'bytes');
console.log('minified   :', min.length, 'bytes');
console.log('bookmarklet:', bookmarklet.length, 'bytes');
console.log('demo page  :', page.length, 'bytes');
