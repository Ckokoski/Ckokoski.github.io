# Case study: TableGrab

**Build Lab | one-click web table to clean CSV | shipped August 18, 2026**

## The interview line

*"I shipped a zero-install browser tool that turns any web table into a spreadsheet-ready CSV.
It expands merged cells, drops CSS-hidden columns, normalizes number formats, and blocks CSV
formula injection. Forty-five automated assertions run it in headless Chromium against tables
built to break it, and the failure modes are published on the page."*

## The problem

Business data lives in HTML tables nobody can export: supplier portals, internal dashboards,
regulatory filings, wiki pages, admin panels with no download button. The manual path is copy,
paste, then fight the result. The result is broken in four predictable ways.

1. Merged cells (`rowspan` / `colspan`) paste as a staircase, so the data is not rectangular
   and cannot be pivoted or joined.
2. Numbers arrive as text. `$1,284,900` is a string. `(42,180)` is a string, not a negative.
   `1.284.900,50` is a string in every locale that did not produce it.
3. Columns the page author hid with CSS come along invisibly, or the visible column count does
   not match what lands in the sheet.
4. Multi-line cells (`<br>`) explode into extra rows and shift everything below them.

So people retype. It takes 30 to 60 minutes per table and introduces typos into numbers that
then get decided on.

## The architecture

One self-contained bookmarklet. No extension, no server, no build step at runtime.

```
click bookmark
  -> find candidates      real <table> elements + ARIA role="table|grid|treegrid"
                          nested tables excluded, layout tables filtered out,
                          same-origin iframes traversed
  -> build grid           HTMLTableElement.rows (correct thead/tbody/tfoot order,
                          nested rows excluded), rowspan/colspan expanded into a
                          rectangle with merged values filled down and across
  -> mark hidden          computed display/visibility, hidden attr, aria-hidden,
                          <colgroup><col> flags, zero-width cells
  -> extract text         footnote <sup> stripped when nothing follows it,
                          <br> to space, form controls report current value,
                          zero-width and non-breaking characters normalized
  -> normalize numbers    currency and thousands separators removed,
                          (n) to -n, European 1.234,56 to 1234.56
  -> prune                fully hidden or fully empty rows and columns dropped
  -> serialize            RFC 4180 CSV, CRLF, UTF-8 BOM, injection guard
  -> deliver              Blob download, or TSV to clipboard for direct paste
```

The UI is rendered into a shadow root so the page's CSS cannot break the overlay and the
overlay cannot break the page.

## The guardrails

**CSV injection is treated as the default case, not the edge case.** A table on a web page is
input from an untrusted party. Any cell beginning with `=`, `+`, `@`, tab or CR is prefixed
with an apostrophe so the spreadsheet treats it as text, unless the value parses as a plain
number, so genuine negatives like `-1250.00` stay numeric. This is verified by test, using
three live payloads including a `HYPERLINK` exfiltration string and a DDE command string.

**No network surface at all.** No `fetch`, no `XMLHttpRequest`, no injected `<script src>`, no
analytics. Verified by grep against the shipped artifact. This is what makes the tool
adoptable inside a company that would never approve an extension, and it is the reason the
annotated source is published on the page rather than only the packed version.

**The tool does not guess.** Ambiguous number formats such as `12,5` are passed through
unchanged rather than converted, because a wrong silent conversion is worse than no
conversion. Predictability is the feature.

**Failure is bounded.** Span attributes are clamped, `getComputedStyle` is wrapped, iframe
access is wrapped, and cross-origin frames fail silently rather than aborting the run. If no
table is found, the tool says so and removes itself.

## Verified result

Two automated suites, 45 assertions, run against real Chromium via Playwright. Not a demo
walkthrough: exact-output assertions on the shipped, minified artifact.

Suite one, four adversarial tables:

- two-level header with `colspan` groups and a three-row `rowspan` label, filled correctly
- `$1,284,900` to `1284900`, `(42,180)` to `-42180`, `1.284.900,50` to `1284900.50`
- footnote markers stripped from labels, exponent superscripts preserved
- CSS-hidden column and hidden template row excluded, and recoverable via a toggle
- multi-line address collapsed to one quoted cell instead of three rows
- ARIA div grid extracted with its hidden column dropped
- three injection payloads neutralized while real negatives stayed numeric
- shadow-root isolation, Escape teardown, second-click toggle, download round trip,
  UTF-8 BOM and CRLF present in the actual downloaded file

Suite two, structural edge cases:

- `<tfoot>` written before `<tbody>` in source still exports last
- nested table flattens into its parent cell without corrupting the outer grid
- zero-width hidden column dropped, empty trailing column dropped
- checkbox and text input states exported from an editable grid
- same-origin iframe table found and extracted
- single-row layout table correctly ignored

Artifact size: 15.4 KB bookmarklet, 21.4 KB annotated source, one 74 KB self-contained page
carrying the installer, four live test tables, the explanation and the full source.

## Where it fails

Published on the tool's own page, not buried here.

- **Virtualized grids** only expose the rows currently rendered. Mitigation: set page size to
  show all rows before grabbing. Not solvable from a bookmarklet without driving the grid's own
  scroll, which would be fragile per vendor.
- **Cross-origin iframes** are blocked by the browser's security model. Correct behavior, not a
  bug. Mitigation: open the frame in its own tab.
- **Canvas-rendered tables** have no DOM structure. That is an OCR problem.
- **A superscript at the very end of a cell** is assumed to be a footnote marker, so a value
  like `12 m²` loses the exponent. Deliberate trade-off: footnote-at-end is far more common in
  business tables than exponent-at-end.
- **Link URLs are not exported**, only visible cell text.
- **Ambiguous number formats are passed through**, by design.

## What it demonstrates

The same pattern as the rest of the Build Lab, applied to a browser instead of an inbox:
deterministic extraction, explicit handling of untrusted input, a named guardrail, published
failure modes, and a verification harness that runs against the shipped artifact rather than
a happy-path demo.

## Files

| File | What it is |
|---|---|
| `tablegrab.html` | The whole deliverable: installer, four live test tables, explanation, annotated source. Host this. |
| `tablegrab.src.js` | Annotated source, 530 lines. |
| `tablegrab.min.js` | Comment-stripped, whitespace-squeezed build. |
| `tablegrab.bookmarklet.txt` | The `javascript:` URL, 15.4 KB. |
| `build.js` | Tokenizer-based minifier and page builder. No third-party dependencies. |
| `test.js` / `test-hard.js` | The two Playwright suites. |
| `fixture-hard.html` | Structural edge-case fixture. |
| `LINKEDIN-POST.md` | Post copy, hooks, replies, hosting instructions. |
| `INFOGRAPHIC-PROMPT.md` | Image prompts for the post. |
