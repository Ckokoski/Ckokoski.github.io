# TableGrab: LinkedIn post kit

## Before you post: one required step

The demo page has to live at a URL. It is a single self-contained HTML file, so hosting takes
about two minutes and costs nothing.

- **Fastest:** go to app.netlify.com/drop and drag `tablegrab.html` onto the page. You get a
  live URL immediately. Rename the site in settings so the URL is not gibberish.
- **Best long term:** a GitHub repo with Pages turned on. Rename the file to `index.html`.
  This one doubles as a portfolio artifact because the annotated source is right there in the
  repo, and it gives you a link you control.

Then replace `[LINK]` below with that URL.

---

## The post

Paste this as-is. It runs about 2,150 characters, well under LinkedIn's 3,000 limit.

---

Somebody on your team is retyping numbers off a screen right now.

It happens every week. A table lives on a supplier portal, an internal dashboard, a regulatory
filing, a wiki page. Somebody needs it in Excel. They select it, they paste it, and they get a
staircase of merged cells, numbers stored as text, and a column of dollar signs that Excel
refuses to add up. So they retype it by hand. Forty minutes, and now there are typos in it.

I built a small free tool that fixes this. No install, no extension, no signup, no account.

It is a bookmarklet. You drag one button to your bookmarks bar, once. From then on, any page
with a table on it gets a CSV button.

What it handles that copy and paste does not:

Merged cells expanded and filled down, so the result is actually pivotable
Hidden columns dropped, because you should export what you can see
Footnote markers stripped off the labels
Multi-line cells collapsed instead of exploding into extra rows
$1,284,900 becomes 1284900. (42,180) becomes -42180. 1.284.900,50 becomes 1284900.50
Dashboard grids built out of divs, which most table scrapers miss completely
UTF-8 and CRLF, so Excel opens it without mangling accented characters

One more, and it is the one I care about most. A table on a web page is input from a stranger.
If a cell starts with an equals sign, a plus or an at sign, most spreadsheets will execute it as
a formula the moment you open the file. That is a real attack, not a theoretical one. Those
cells get quoted as text before they ever reach your machine.

Where it fails, because everything has a list: virtualized grids only give you the rows
currently rendered, so set the page size to "all" before you grab. Cross-origin iframes are off
limits by browser design. A table drawn on a canvas has no structure to read at all.

The entire program lives inside the bookmark. Nothing is uploaded, there is no analytics and no
remote script, and the annotated source is printed on the page so you can read every line
before you decide to trust it.

Link is in the first comment. Take it, use it at work, hand it to your team.

If it breaks on something, tell me what the table was. The ugly real-world ones are what make
the next version better.

---

## First comment (post this yourself, immediately)

Here it is: [LINK]

Drag the button to your bookmarks bar, then try it on the four sample tables on that page.
Each one is built to break a normal copy and paste. Works in Chrome, Edge, Firefox and Safari.
Nothing to install and nothing for IT to approve, because a bookmarklet is just a bookmark.

---

## Alternate hooks

Swap the first line if you want a different angle. Keep the rest the same.

1. **Cost angle:** "The most expensive software in most companies is a person retyping numbers
   off a screen."
2. **Confession angle:** "I watched someone retype a 60 row table off a dashboard last month
   because pasting it made a mess. That is a solved problem, so I solved it."
3. **Specific angle:** "Copy a table off a web page, paste it into Excel, and you get merged
   cells, numbers stored as text, and a column Excel will not sum. Here is the fix."
4. **Security angle:** "If a cell in a downloaded CSV starts with an equals sign, your
   spreadsheet may run it as a formula. Most table exporters do nothing about this."

---

## If you want the short version instead

Under 700 characters. Use this if you would rather lead with the image and let the demo page do
the talking.

---

Copy a table off a web page into Excel and you get a staircase of merged cells, numbers stored
as text, and a column of dollar signs that will not add up. So people retype it by hand.

I built a free bookmarklet that fixes it. Drag one button to your bookmarks bar and every page
with a table gets a CSV button. Merged cells filled down, hidden columns dropped, footnote
markers stripped, currency and thousands separators removed, accounting parentheses turned into
real negatives.

No install, no signup, no network calls. The source is printed on the page.

Link in the first comment. Free, take it to work.

---

## Replies worth having ready

**"Is this safe / what is a bookmarklet?"**
A bookmarklet is a bookmark whose address is a small program instead of a web address. It only
runs when you click it, only on the tab you are looking at. This one makes no network requests
at all, which you can verify in your network tab or by reading the source on the page. That is
why I published the readable version rather than only the packed one.

**"Why not just use a Chrome extension?"**
Extensions need approval in most managed environments and they run on every page all the time.
This runs only when you click it and there is nothing to install.

**"It did not work on [site]."**
Tell me the pattern rather than the URL if the site is private. The three known cases are
virtualized grids that only render visible rows, tables inside cross-origin iframes, and tables
drawn onto a canvas. The first one is usually fixed by setting the page size to show everything
first.

**"Can you add [feature]?"**
Ask. Link URLs from cells and a straight Google Sheets push are the two most requested things I
have already considered.

---

## Images to attach

Attach two, in this order. The generated infographic is the scroll stopper, the screenshot is
the proof.

1. `infographic.png`, generated from `INFOGRAPHIC-PROMPT.md`
2. `proof-before-after.png`, a real screenshot of the tool's actual output

A short screen recording of you clicking the bookmark and the file landing in your downloads
bar will outperform both if you have thirty seconds to record one. Real UI in motion is the
least fakeable proof there is.

---

## Timing

Tuesday to Thursday, 8am to 10am in your audience's time zone. Reply to every comment in the
first two hours. Do not edit the post for the first hour, and keep the link in the comment
rather than the body.
