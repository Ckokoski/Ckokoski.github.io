# Infographic prompts for GPT Images 2

Three prompts. Use **Prompt A** as the single post image. Use the set in **Prompt C** if you
want a carousel. Everything is written to be pasted into ChatGPT as-is.

## Two rules that decide whether this looks good

1. **Image models still misspell.** Every word you want rendered is listed explicitly below and
   nowhere else. Do not add more copy to the prompt. Fewer words means fewer errors.
2. **Check the spelling before you post.** Read every word in the generated image. If one is
   wrong, reply with: `Regenerate. Keep the exact layout and style. Fix only the text, spelling
   must be exact: "<the correct string>".` That works better than describing the error.

---

## Prompt A: the before and after (use this one)

```
Create a clean, modern infographic image, 4:5 portrait aspect ratio, 1080 x 1350 pixels,
for a LinkedIn post about a productivity tool.

Style: flat vector, corporate but not sterile, generous white space, thin 1px borders,
soft rounded corners, subtle drop shadows. No people, no photographs, no 3D, no gradients
on text, no stock-photo business imagery, no clip art icons of laptops.

Palette: off-white background (#F8FAFC), near-black text (#0F172A), muted slate grey for
secondary text (#64748B), one accent colour of indigo (#6366F1), a muted red (#DC2626)
used only for the "before" side, a muted green (#059669) used only for the "after" side.

Layout, top to bottom:

1. Title across the top, large bold sans-serif, near-black, left aligned, two lines:
   "Copy a web table into Excel"
   "and this is what you get"

2. Below it, two panels side by side, equal width, separated by a thin vertical gap.
   Each panel is a white rounded card.

   LEFT PANEL, small red label at the top reading "PASTE"
   Inside: a small spreadsheet grid, roughly 5 columns by 5 rows, drawn as thin grey
   cell borders. Show it broken: several cells merged into a staircase shape stepping
   down to the right, three cells left empty, two cells showing a small red warning
   triangle. The overall impression is a misaligned, jagged mess.

   RIGHT PANEL, small green label at the top reading "TABLEGRAB"
   Inside: the same size grid, 5 columns by 5 rows, perfectly rectangular and aligned,
   every cell filled with an abstract grey bar representing text, the first row shaded
   light indigo to represent a header row, right-aligned shorter bars in the last two
   columns to represent numbers. The impression is calm and orderly.

3. Below the two panels, a single horizontal row of four small indigo checkmark icons,
   each with one short label underneath, all in the same small bold sans-serif:
   "Merged cells"
   "Hidden columns"
   "Real numbers"
   "Safe formulas"

4. At the very bottom, one thin line of small grey text, centered:
   "One click. No install."

Render ONLY the text strings listed above. Do not invent any other words, labels, numbers,
watermarks or signatures anywhere in the image. Spell every word exactly as written.
```

---

## Prompt B: the pipeline diagram (alternative, more technical)

Use this if you want the post to read as engineering rather than productivity.

```
Create a clean technical diagram, 4:5 portrait aspect ratio, 1080 x 1350 pixels, in a flat
vector infographic style for LinkedIn.

Style: flat vector, thin 1.5px strokes, rounded rectangles, plenty of white space, no people,
no photographs, no 3D. Palette: off-white background (#F8FAFC), near-black text (#0F172A),
grey secondary text (#64748B), indigo accent (#6366F1).

Layout: a single vertical flow, top to bottom, five rounded rectangle nodes connected by
thin indigo arrows pointing downward. Each node is a white card with a thin border. Inside
each node, one short bold label. The labels, in order from top to bottom:

"Any web table"
"Expand merged cells"
"Drop hidden data"
"Normalize numbers"
"Clean CSV"

To the right of the middle three nodes, place small grey annotation text, one line each,
connected by a short thin grey line:

next to "Expand merged cells": "rowspan and colspan"
next to "Drop hidden data": "what you see is what you export"
next to "Normalize numbers": "$1,284,900 becomes 1284900"

At the top of the image, a bold title in two lines, left aligned:
"How a web table becomes"
"a spreadsheet you can trust"

At the bottom, one small grey line, centered: "Runs entirely in your browser."

Render ONLY the text strings listed above. Do not invent any other words or numbers anywhere
in the image. Spell every string exactly as written, including the dollar amount.
```

---

## Prompt C: the carousel (five slides, strongest option)

Run these one at a time in the same ChatGPT conversation so the style stays consistent. After
slide 1, start each follow-up with: `Same style, same palette, same 4:5 size. Next slide:`

**Slide 1, the hook**

```
Create a 4:5 portrait image, 1080 x 1350 pixels, flat vector infographic style,
off-white background (#F8FAFC), near-black text (#0F172A), indigo accent (#6366F1),
generous white space, no people, no photographs.

Centered, large bold sans-serif text on three lines:
"Nobody should be"
"retyping numbers"
"off a screen"

Below the text, a single simple line drawing in indigo: a small spreadsheet grid with one
cell highlighted, and a thin arrow curving away from it.

Render only those three lines of text. No other words anywhere.
```

**Slide 2, the problem**

```
Same style, same palette, same 4:5 size. Next slide:

Title at the top, bold, two lines, left aligned:
"What a paste actually"
"does to a table"

Below it, one large white rounded card containing a spreadsheet grid, 5 columns by 6 rows,
drawn with thin grey borders, deliberately broken: merged cells forming a staircase, three
empty cells, two cells with a small muted red warning triangle, one column of cells showing
left-aligned text where numbers should be right-aligned.

At the bottom, three short grey lines of text stacked, left aligned:
"Merged cells become a staircase"
"Numbers arrive as text"
"Hidden columns come along for the ride"

Render only those text strings. No other words anywhere.
```

**Slide 3, the fix**

```
Same style, same palette, same 4:5 size. Next slide:

Title at the top, bold, two lines, left aligned:
"One click,"
"one clean file"

Below it, one large white rounded card containing a spreadsheet grid, 5 columns by 6 rows,
perfectly rectangular and aligned, first row shaded light indigo as a header, every cell
filled with an abstract grey bar, the last two columns showing shorter right-aligned bars
to represent numbers.

At the bottom, three short grey lines stacked, left aligned:
"Merged cells filled down"
"Numbers as numbers"
"You export what you can see"

Render only those text strings. No other words anywhere.
```

**Slide 4, the security point**

```
Same style, same palette, same 4:5 size. Next slide:

Title at the top, bold, two lines, left aligned:
"A web table is input"
"from a stranger"

In the middle, a single white rounded card. Inside it, one line of monospace text in muted
red on a light grey background:
"=HYPERLINK(...)"

Below that card, a thin downward indigo arrow, then a second white rounded card with the
same text in grey, with a small indigo shield icon beside it and a short label underneath:
"Quoted as text"

At the bottom, one line of small grey text, centered:
"Spreadsheets will run that. Mine will not."

Render only those text strings. No other words anywhere.
```

**Slide 5, the call to action**

```
Same style, same palette, same 4:5 size. Final slide:

Centered, large bold text on two lines:
"Free. No install."
"Link in the comments."

Below it, a single indigo rounded rectangle shaped like a browser bookmark button, with the
words "Grab Table" inside it in white bold text, and a thin dashed arrow curving up from the
button toward the top edge of the image to suggest dragging it to a bookmarks bar.

At the bottom, one small grey line, centered:
"Built by Christopher Kokoski"

Render only those text strings. No other words anywhere.
```

---

## After you generate

- Read every word. Fix spelling with the regenerate instruction at the top of this file.
- Post the generated image first and the real screenshot second. The infographic earns the
  stop, the screenshot earns the trust.
- If a generated image comes back cluttered, add this line to the prompt and rerun:
  `Reduce it. Remove any element not explicitly listed. More white space.`
