// Second suite: structural edge cases that break most table scrapers.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const code = fs.readFileSync('tablegrab.min.js', 'utf8');
const url = 'file://' + path.resolve('fixture-hard.html');

let failures = 0;
function check(name, actual, expected) {
  const a = JSON.stringify(actual), e = JSON.stringify(expected);
  if (a === e) console.log('  PASS  ' + name);
  else { failures++; console.log('  FAIL  ' + name + '\n        expected: ' + e + '\n        actual  : ' + a); }
}

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
  const errs = [];
  page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(url);
  await page.waitForTimeout(150);
  await page.evaluate(code);

  const data = await page.evaluate(() => {
    const g = window.__tableGrab__;
    return g.found.map((f) => ({
      id: f.el.id || '(iframe)',
      sameDoc: f.doc === document,
      rows: g.extract(f)
    }));
  });

  console.log('\nStructural edge cases');
  check('layout table with one row is ignored',
    data.some((d) => d.id === 'e'), false);
  check('nested table is not offered as its own export',
    data.length, 4);

  const a = data.find((d) => d.id === 'a').rows;
  check('tfoot written before tbody still exports last',
    a, [['Line', 'Amount'], ['Software', '4100'], ['Contractors', '5200'], ['Total', '9300']]);

  const b = data.find((d) => d.id === 'b').rows;
  check('nested table flattens into its parent cell without wrecking the grid',
    b, [['Program', 'Milestones'],
        ['Onboarding refresh', 'Draft Mar 4 Pilot Apr 18'],
        ['Vendor audit', 'Single milestone']]);

  const c = data.find((d) => d.id === 'c').rows;
  check('zero-width column dropped and empty trailing column dropped',
    c[0], ['Team', 'Approved', 'Open roles']);
  check('checkbox state exported as TRUE/FALSE, input values read',
    c[1], ['Platform', 'TRUE', '3']);
  check('unchecked checkbox exported as FALSE', c[2], ['Support', 'FALSE', '7']);

  const f = data.find((d) => !d.sameDoc);
  check('same-origin iframe table is found',
    f ? f.rows : null,
    [['Site', 'Uptime'], ['Ashgrove', '99.4%'], ['Beckworth', '97.1%']]);

  check('no uncaught page errors', errs, []);
  await browser.close();
  console.log(failures === 0 ? '\nALL HARD-CASE CHECKS PASSED' : '\n' + failures + ' FAILED');
  process.exit(failures === 0 ? 0 : 1);
})();
