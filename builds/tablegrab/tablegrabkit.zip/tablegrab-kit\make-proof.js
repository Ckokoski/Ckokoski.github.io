// Builds a real before/after proof image from actual tool output.
// Nothing here is mocked: the CSV panel is the exact string the bookmarklet
// produced from the table shown on the left.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const code = fs.readFileSync('tablegrab.min.js', 'utf8');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  await page.goto('file://' + path.resolve('tablegrab.html'));
  await page.evaluate(code);

  const { csv, html } = await page.evaluate(() => {
    const g = window.__tableGrab__;
    return {
      csv: g.csv(g.extract(g.found[0])),
      html: document.querySelector('#t-financial').outerHTML
    };
  });
  await browser.close();

  const styles = fs.readFileSync('tablegrab.html', 'utf8').match(/<style>([\s\S]*?)<\/style>/)[1];

  const proof = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
${styles}
body{background:#f1f5f9;margin:0;padding:34px;font:15px ui-sans-serif,system-ui,sans-serif}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:26px;align-items:start;max-width:1330px;margin:0 auto}
.panel{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:20px;box-shadow:0 2px 10px rgba(15,23,42,.05)}
.panel h4{margin:0 0 3px;font-size:15px;color:#0f172a}
.panel .sub2{margin:0 0 15px;font-size:12.5px;color:#64748b}
pre{margin:0;font:12.5px/1.75 ui-monospace,Menlo,Consolas,monospace;color:#0f172a;
    background:#f8fafc;border:1px solid #e2e8f0;border-radius:9px;padding:15px;white-space:pre;overflow:auto}
.head{max-width:1330px;margin:0 auto 22px}
.head h2{font-size:23px;margin:0 0 4px}
.head p{margin:0;color:#64748b;font-size:14px}
table.sample{font-size:12.5px}
table.sample th,table.sample td{padding:6px 9px}
.note{margin:13px 0 0;font-size:12px;color:#475569}
.note b{color:#0f172a}
</style></head><body>
<div class="head">
  <h2>One click, on a table built to break copy and paste</h2>
  <p>Left: what is on the page. Right: the exact CSV produced, nothing edited.</p>
</div>
<div class="grid">
  <div class="panel">
    <h4>On the page</h4>
    <p class="sub2">Two header rows, a region spanning three rows, accounting parentheses, a European number format, footnote markers, and one column hidden from view.</p>
    ${html}
  </div>
  <div class="panel">
    <h4>In your spreadsheet</h4>
    <p class="sub2">Rectangular, filled down, numbers as numbers, hidden column excluded.</p>
    <pre>${csv.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]))}</pre>
    <p class="note"><b>Note the details:</b> "Revenue<sup>1</sup>" lost its footnote marker, (42,180) became -42180,
    1.284.900,50 became 1284900.50, and the internal margin column did not come along.</p>
  </div>
</div>
</body></html>`;

  fs.writeFileSync('proof-comparison.html', proof);

  const b2 = await chromium.launch();
  const p2 = await b2.newPage({ viewport: { width: 1400, height: 760 }, deviceScaleFactor: 2 });
  await p2.goto('file://' + path.resolve('proof-comparison.html'));
  await p2.waitForTimeout(200);
  await p2.locator('body').screenshot({ path: 'proof-before-after.png' });
  await b2.close();
  console.log('wrote proof-before-after.png');
})();
